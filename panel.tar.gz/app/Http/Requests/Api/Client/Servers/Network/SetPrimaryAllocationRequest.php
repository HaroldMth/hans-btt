<?php

namespace Pterodactyl\Http\Requests\Api\Client\Servers\Network;

class SetPrimaryAllocationRequest extends UpdateAllocationRequest
{
    public function rules(): array
    {
        return [];
    }
}
